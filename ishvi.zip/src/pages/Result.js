import React from 'react';
import { styled } from "@mui/material/styles";
import { Box } from '@mui/system';
import MenuIcon from '@mui/icons-material/Menu';
import { Avatar, BottomNavigation, BottomNavigationAction, Button, Chip, FormControl, Grid, IconButton, InputLabel, MenuItem, OutlinedInput, Paper, Select, TextField, Typography } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ShareOutlinedIcon from '@mui/icons-material/ShareOutlined';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import Scholar from '../img/scholarship.png';
import Programs from '../img/programs.png';
import Sop from '../img/sop.png';
import Reset from '../img/reset.png';
import Submit from '../img/submit.png';
import Sort from '../img/sort.png';
import User from '../img/user.png';
import College from '../img/college.png';
import Percentage from '../img/percenatge.png';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import FilterAltOutlinedIcon from '@mui/icons-material/FilterAltOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import axios from 'axios';

const useStyles = styled((theme) => ({
    root: {
        flexGrow: 1,
        bgcolor: '#E5E5E5',
        fontFamily: 'Montserrat'
    }

}));



const names = [
    'Oliver Hansen',
    'Van Henry',
    'April Tucker',
    'Ralph Hubbard',
    'Omar Alexander',
    'Carlos Abbott',
    'Miriam Wagner',
    'Bradley Wilkerson',
    'Virginia Andrews',
    'Kelly Snyder',
];

const Result = () => {
    const classes = useStyles();
    // const response = await axios.post("/");

    const [value, setValue] = React.useState('recents');

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    return (
        <Box className={classes.root} sx={{ bgcolor: '#fafafa', }}>
            <Box sx={{ display: 'inline', display: 'flex', flexGrow: 1, flexDirection: 'row', bgcolor: '#fafafa', marginBottom: 2, }}>
                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, marginLeft: 1, }}
                >
                    <MenuIcon sx={{ fontSize: 30 }} />
                </IconButton>

                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, flex: 2, justifyContent: 'flex-end' }}
                >
                    <SearchIcon sx={{ fontSize: 25 }} />
                </IconButton>

                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, justifyContent: 'flex-end' }}
                >
                    <ShareOutlinedIcon sx={{ fontSize: 25 }} />
                </IconButton>

                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, justifyContent: 'flex-end' }}
                >
                    <NotificationsNoneIcon sx={{ fontSize: 25 }} />
                </IconButton>

                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, marginRight: 1, justifyContent: 'flex-end' }}
                >
                    <img src={User} />
                </IconButton>


            </Box>
            <Box sx={{

                marginLeft: 2,
                marginRight: 2,
                borderRadius: 2,

            }}>
                <Grid container spacing={1}>
                    <Grid item xs={6} sx={{ mt: 1, fontWeight: 'bold' }}>
                        Universities <span style={{ color: '#1B6CFC' }}>1260</span>
                    </Grid>
                    <Grid item xs={6} sx={{ textAlign: 'end' }}>
                        <IconButton
                            size="small"
                            edge="end"
                            aria-label="account of current user"
                            // aria-controls={menuId}
                            aria-haspopup="true"

                            color="inherit"

                        >
                            <ShareOutlinedIcon />
                        </IconButton>
                    </Grid>

                </Grid>
                <hr />


            </Box>

            <Box sx={{
                marginLeft: 2,
                marginRight: 2,
                borderRadius: 2,
                marginTop: 3,
            }}>
                <Chip label="Programs" sx={{ bgcolor: '#fff' }} />

                <Chip icon={<FilterAltOutlinedIcon />} label="Filter" sx={{ bgcolor: '#fff', float: 'right', }} />
                <Chip avatar={<img alt="Natacha" src={Sort} />} label="Sort" sx={{ bgcolor: '#fff', float: 'right', mx: 1 }} />
            </Box>

            <Box sx={{
                marginLeft: 2,
                marginRight: 2,
                borderRadius: 2,
                marginTop: 3,
            }}>
                <Box sx={{ bgcolor: '#fff', borderRadius: 3, py: 1, mb: 1 }}>
                    <Grid container>
                        <Grid item xs={2}><img src={College} /></Grid>
                        <Grid item xs={10} sx={{ pl: 1, position: 'relative' }}>
                            <Typography sx={{ fontWeight: 'bold', fontSize: '15px', mt: 1 }}>The College of saint Rose</Typography>
                            <Typography sx={{ fontSize: '13px' }}>Computer Information System</Typography>
                            <hr style={{ maxWidth: '70%', marginRight: '30%', color: '#fff' }} />

                            <Typography sx={{ mt: 1, fontSize: '15px' }}>May (01-01-1970)  <span style={{ float: 'right', marginRight: '10px', fontWeight: 'bold', fontSize: '16px' }}>$25000</span></Typography>

                            <img src={Percentage} style={{ marginTop: '15px' }} />
                            <Chip label="Apply" sx={{ bgcolor: '#1B6CFC', color: '#fff', position: 'absolute', marginTop: '5px', right: 0, marginRight: '25px', }} />

                            <Box sx={{ position: 'absolute', top: 0, right: 0 }}>
                                <IconButton
                                    size="small"
                                    edge="end"
                                    aria-label="account of current user"
                                    // aria-controls={menuId}
                                    aria-haspopup="true"

                                    color="inherit"

                                >
                                    <FavoriteBorderIcon />
                                </IconButton>
                                <IconButton
                                    size="small"
                                    edge="end"
                                    aria-label="account of current user"
                                    // aria-controls={menuId}
                                    aria-haspopup="true"

                                    color="inherit"

                                >
                                    <MoreVertIcon />
                                </IconButton>
                            </Box>
                        </Grid>
                    </Grid>


                </Box>

                <Box sx={{ bgcolor: '#fff', borderRadius: 3, py: 1, mb: 1 }}>
                    <Grid container>
                        <Grid item xs={2}><img src={College} /></Grid>
                        <Grid item xs={10} sx={{ pl: 1, position: 'relative' }}>
                            <Typography sx={{ fontWeight: 'bold', fontSize: '15px', mt: 1 }}>The College of saint Rose</Typography>
                            <Typography sx={{ fontSize: '13px' }}>Computer Information System</Typography>
                            <hr style={{ maxWidth: '70%', marginRight: '30%', color: '#fff' }} />

                            <Typography sx={{ mt: 1, fontSize: '15px' }}>May (01-01-1970)  <span style={{ float: 'right', marginRight: '10px', fontWeight: 'bold', fontSize: '16px' }}>$25000</span></Typography>

                            <img src={Percentage} style={{ marginTop: '15px' }} />
                            <Chip label="Apply" sx={{ bgcolor: '#1B6CFC', color: '#fff', position: 'absolute', marginTop: '5px', right: 0, marginRight: '25px', }} />

                            <Box sx={{ position: 'absolute', top: 0, right: 0 }}>
                                <IconButton
                                    size="small"
                                    edge="end"
                                    aria-label="account of current user"
                                    // aria-controls={menuId}
                                    aria-haspopup="true"

                                    color="inherit"

                                >
                                    <FavoriteBorderIcon />
                                </IconButton>
                                <IconButton
                                    size="small"
                                    edge="end"
                                    aria-label="account of current user"
                                    // aria-controls={menuId}
                                    aria-haspopup="true"

                                    color="inherit"

                                >
                                    <MoreVertIcon />
                                </IconButton>
                            </Box>
                        </Grid>
                    </Grid>


                </Box>


            </Box>




            <Paper sx={{ position: 'fixed', bottom: 0, left: 0, right: 0, pb: 2, pt: 1 }} elevation={3}>
                <BottomNavigation
                    showLabels
                    value={value} onChange={handleChange}
                    sx={{ fontFamily: 'Montserrat' }}
                >
                    <BottomNavigationAction sx={{ fontFamily: 'Montserrat' }} label="Home" icon={<HomeOutlinedIcon />} />
                    <BottomNavigationAction label="Favorites" icon={<FavoriteBorderIcon />} />
                    <BottomNavigationAction label="Documents" icon={<AssignmentOutlinedIcon />} />
                    <BottomNavigationAction label="WhatsApp" icon={<WhatsAppIcon />} />
                    <BottomNavigationAction sx={{ fontFamily: 'Montserrat' }} label="More" icon={<MoreHorizIcon />} />
                </BottomNavigation>
            </Paper>
        </Box >
    )
}

export default Result;
