import React, { useState } from 'react';
import { styled } from "@mui/material/styles";
import { Box } from '@mui/system';
import MenuIcon from '@mui/icons-material/Menu';
import { BottomNavigation, BottomNavigationAction, Button, Chip, FormControl, Grid, IconButton, InputLabel, MenuItem, OutlinedInput, Paper, Select, TextField, Typography } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ShareOutlinedIcon from '@mui/icons-material/ShareOutlined';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import Scholar from '../img/scholarship.png';
import Programs from '../img/programs.png';
import Sop from '../img/sop.png';
import Reset from '../img/reset.png';
import Submit from '../img/submit.png';
import User from '../img/user.png';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import axios from 'axios';


const useStyles = styled((theme) => ({
    root: {
        flexGrow: 1,
        bgcolor: '#E5E5E5',
        fontFamily: 'Montserrat'
    }

}));



const names = [
    'Oliver Hansen',
    'Van Henry',
    'April Tucker',
    'Ralph Hubbard',
    'Omar Alexander',
    'Carlos Abbott',
    'Miriam Wagner',
    'Bradley Wilkerson',
    'Virginia Andrews',
    'Kelly Snyder',
];

const Home = () => {
    const classes = useStyles();

    const [value, setValue] = React.useState('recents');

    const [degree, setDegree] = useState('');
    const [program, setProgram] = useState('');
    const [country, setCountry] = useState('');

    const submit = async () => {
        const response = await axios.post("https://erp.bscglobaledu.com/mapi/JsonApi/", {
            degree_type: degree, program: program, country: country, page: '1', operation: 'profileEvaluationDetails', call_frm: 'mobile', userid: '633575'
        }, {
            'Access-Control-Allow-Origin': '*',
        });

        console.log(response);
    }

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    return (
        <Box className={classes.root} sx={{ bgcolor: '#fafafa', }}>
            <Box sx={{ display: 'inline', display: 'flex', flexGrow: 1, flexDirection: 'row', bgcolor: '#fafafa' }}>
                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, marginLeft: 1, }}
                >
                    <MenuIcon sx={{ fontSize: 30 }} />
                </IconButton>

                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, flex: 2, justifyContent: 'flex-end' }}
                >
                    <SearchIcon sx={{ fontSize: 25 }} />
                </IconButton>

                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, justifyContent: 'flex-end' }}
                >
                    <ShareOutlinedIcon sx={{ fontSize: 25 }} />
                </IconButton>

                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, justifyContent: 'flex-end' }}
                >
                    <NotificationsNoneIcon sx={{ fontSize: 25 }} />
                </IconButton>

                <IconButton
                    size="large"
                    edge="end"
                    aria-label="account of current user"
                    // aria-controls={menuId}
                    aria-haspopup="true"

                    color="inherit"
                    sx={{ marginTop: 2, marginRight: 1, justifyContent: 'flex-end' }}
                >
                    <img src={User} />
                </IconButton>


            </Box>
            <Box sx={{
                bgcolor: '#fff',
                marginLeft: 2,
                marginRight: 2,
                borderRadius: 2,
                marginTop: 4,
            }}>
                <Typography sx={{ padding: 2, fontFamily: 'Montserrat' }}>
                    Search Universities
                </Typography>

                <FormControl fullWidth sx={{ my: 1, }}>
                    <InputLabel sx={{ fontFamily: 'Montserrat', mx: 2 }}>Degree Type</InputLabel>
                    <Select
                        sx={{ borderRadius: 2, mx: 2 }}
                        input={<OutlinedInput label="Degree Type" />}
                        onChange={(e) => setDegree(e.target.value)}
                    >
                        <MenuItem value='Masters' selected>
                            Masters
                        </MenuItem>

                    </Select>
                </FormControl>

                <FormControl fullWidth sx={{ my: 1, }}>
                    <InputLabel sx={{ fontFamily: 'Montserrat', mx: 2 }}>Program Name</InputLabel>
                    <Select
                        sx={{ borderRadius: 2, mx: 2 }}
                        input={<OutlinedInput label="Program Name" />}
                        onChange={(e) => setProgram(e.target.value)}
                    >
                        <MenuItem selected value="Aerospace Engineering">
                            Aerospace Engineering
                        </MenuItem>

                    </Select>
                </FormControl>

                <FormControl fullWidth sx={{ my: 1, }}>
                    <InputLabel sx={{ fontFamily: 'Montserrat', mx: 2 }}>Country</InputLabel>
                    <Select
                        sx={{ borderRadius: 2, mx: 2 }}
                        input={<OutlinedInput label="Country" />}
                        onChange={(e) => setCountry(e.target.value)}
                    >
                        <MenuItem selected value="USA">
                            USA
                        </MenuItem>

                    </Select>
                </FormControl>

                <Grid container spacing={1}>
                    <Grid item mx='auto' xs={6} sx={{ textAlign: 'center', }}>
                        <img src={Reset} width="180px" />

                    </Grid>
                    <Grid item mx='auto' xs={6} sx={{ textAlign: 'center', mt: 1 }}>
                        <img onClick={submit} src={Submit} width="150px" />
                    </Grid>
                </Grid>

            </Box>

            <Box sx={{ height: '500px' }}>
                <Grid container sx={{ textAlign: 'center', mt: 3, }} spacing={1}>
                    <Grid mx='auto' item sx={{ position: 'relative' }}>
                        <img src={Scholar} width="100px" />
                        <Chip sx={{ position: 'absolute', left: 0, right: 0, ml: 'auto', mr: 'auto', width: '60%', mt: 10, bgcolor: '#FFFFFF', boxShadow: 1, fontFamily: 'Montserrat' }} label="View" variant="filled" />
                    </Grid>
                    <Grid mx='auto' item sx={{ position: 'relative' }}>
                        <img src={Programs} width="100px" />
                        <Chip sx={{ position: 'absolute', left: 0, right: 0, ml: 'auto', mr: 'auto', width: '60%', mt: 10, bgcolor: '#FFFFFF', boxShadow: 1, fontFamily: 'Montserrat' }} label="View" variant="filled" />
                    </Grid>
                    <Grid mx='auto' item sx={{ position: 'relative' }}>
                        <img src={Sop} width="100px" />
                        <Chip sx={{ position: 'absolute', left: 0, right: 0, ml: 'auto', mr: 'auto', width: '60%', mt: 10, bgcolor: '#FFFFFF', boxShadow: 1, fontFamily: 'Montserrat' }} label="View" variant="filled" />
                    </Grid>
                </Grid>
            </Box>


            <Paper sx={{ position: 'fixed', bottom: 0, left: 0, right: 0, pb: 2, pt: 1 }} elevation={3}>
                <BottomNavigation
                    showLabels
                    value={value} onChange={handleChange}
                    sx={{ fontFamily: 'Montserrat' }}
                >
                    <BottomNavigationAction sx={{ fontFamily: 'Montserrat' }} label="Home" icon={<HomeOutlinedIcon />} />
                    <BottomNavigationAction label="Favorites" icon={<FavoriteBorderIcon />} />
                    <BottomNavigationAction label="Documents" icon={<AssignmentOutlinedIcon />} />
                    <BottomNavigationAction label="WhatsApp" icon={<WhatsAppIcon />} />
                    <BottomNavigationAction sx={{ fontFamily: 'Montserrat' }} label="More" icon={<MoreHorizIcon />} />
                </BottomNavigation>
            </Paper>
        </Box >
    )
}

export default Home;
